
package triangulos;

import java.util.Scanner;

/**
 *
 * @author Asus
 */
public class Triangulos {
    public static void main(String[] args) {
    Scanner leer = new Scanner (System.in);
   double L1, L2, L3;
   System.out.print("Digite el lado mayor");
   L1 = leer.nextDouble();
   System.out.print("Digite el segundo lado ");
   L2 = leer.nextDouble();
   System.out.print("Digite el ultimo lado ");
   L3 = leer.nextDouble();
   if (L1>L2+L3){
       System.out.print("No es un triangulo");
   } else 
   {  if (L1 == L2&&L2 == L3) {
          System.out.print("Es un triangulo equilatero");
      } else { if (L1 == L2||L2 == L3 || L1 == L3){
          System.out.print("Es un triangulo isosceles"); }
      else { System.out.print("Es un triangulo escaleno");
      }
      }
      }
      
      }
   }
    
    

